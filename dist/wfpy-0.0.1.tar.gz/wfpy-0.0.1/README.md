# wfpy
Package with several tools used to analyse data from QMC methods.

# Installation

python setup.py sdist

pip install ./dist/wfpy-0.0.1.tar.gz
